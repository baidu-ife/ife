define(['Window','dom'],function(a,dom){
    function hello() {
        alert('hello,world!');
    }
    return {
        hello:hello
    };
});